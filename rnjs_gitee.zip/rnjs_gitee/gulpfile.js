'use strict';

const gulp = require('gulp');
const semver = require('semver');
const fs = require('fs');
const argv = require('minimist')(process.argv.slice(2));  // -log是保留字
const $ = require('gulp-load-plugins')({});
const shell = require('child_process');
let pkg = require('./package.json');

const BAK_PATH = '../../_bak/';
let oldPkgVersion = pkg.version;
let oldReadme = null;

Date.prototype.format = function (fmt) {
  let o = {
    'M+': this.getMonth() + 1,
    'd+': this.getDate(),
    'h+': this.getHours(),
    'm+': this.getMinutes(),
    's+': this.getSeconds(),
    'q+': Math.floor((this.getMonth() + 3) / 3),
    'S': this.getMilliseconds()
  };
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (let k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (('00' + o[k]).substr(("" + o[k]).length)));
  }
  return fmt;
}

function Promisify (fn, receiver) {
  return (...args) => {
    return new Promise((resolve, reject) => {
      fn.apply(receiver, [...args, (err, res) => {
        return err ? reject(err) : resolve(res);
      }]);
    });
  };
}

// 自动更新package.json版本号
gulp.task('version', () => {
  let newVer = argv.version;
  if (!newVer) {
    newVer = semver.inc(pkg.version, 'patch');
  }
  return gulp.src('./package.json')
    .pipe($.bump({
      version: newVer
    }))
    .pipe(gulp.dest('./'))
    .on('end', () => {
      pkg.version = newVer;
    })
});

// 记录日志
gulp.task('changlog', () => {
  let readme = fs.readFileSync(`${ __dirname }/readme.md`).toString();
  oldReadme = readme;
  let tag = '## Change Log';
  let arr = readme.split(tag);
  let str = `
**${ pkg.version }：** ${ new Date().format('yyyy-MM-dd hh:mm')}
>${ argv.logs || ' ' }
  `;
  arr[1] = str + (arr[1] || '');
  return fs.writeFileSync(`${ __dirname }/readme.md`, arr.join(tag));
});


// 发布到私有NPM库
gulp.task('publish2npm', async () => {
  try {
    await Promisify(shell.exec, shell)('npm publish --registry http://npm.richlee.cn:5873/', {maxBuffer: 200 * 1024});
  } catch (err) {
    // 恢复数据
    gulp.src('./package.json')
      .pipe($.bump({
        version: oldPkgVersion
      }))
      .pipe(gulp.dest('./'));
    if (oldReadme) {
      fs.writeFileSync(`${ __dirname }/readme.md`, oldReadme);
    }
    throw err;
  }
  return true;
});

// 发布到GIT库
// git config --global user.email "artgou@163.com"
gulp.task('publish2git', async () => {
  try {
    await Promisify(shell.exec, shell)(`
      git add . 
      git commit -m 
    '${argv.m || '无'}'  `, {maxBuffer: 200 * 1024});
  } catch (err) {
    // 恢复数据
    gulp.src('./package.json')
      .pipe($.bump({
        version: oldPkgVersion
      }))
      .pipe(gulp.dest('./'));
    if (oldReadme) {
      fs.writeFileSync(`${ __dirname }/readme.md`, oldReadme);
    }
    throw err;
  }
  return true;
});

// 本地 - 备份
gulp.task('backup', () => {
  let bakName_zip = pkg.name + '_' + pkg.version + (argv.name ? '_' + argv.name : '') + '.zip';
  return gulp.src(['./**/*', '!**/node_modules/**'])
    .pipe($.zip(bakName_zip))
    .pipe(gulp.dest(BAK_PATH))
    // .on('end', () => {
    //   console.log('备份成功：' + BAK_PATH);
    // })
});

// 发布
// gulp.task('publish', $.sequence('version', 'changlog', 'publish2npm', 'backup'));
// gulp git -m 修改日志可以不加引号
gulp.task('git', $.sequence('version', 'changlog', 'publish2git'));
